create function st_valuepercent(rast raster, searchvalue double precision, roundto double precision DEFAULT 0) returns double precision
LANGUAGE SQL
AS $$
SELECT (_st_valuecount($1, 1, TRUE, ARRAY[$2]::double precision[], $3)).percent
$$;
