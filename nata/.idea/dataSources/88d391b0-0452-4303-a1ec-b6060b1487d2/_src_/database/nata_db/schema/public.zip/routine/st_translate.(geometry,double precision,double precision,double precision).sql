create function st_translate(geometry, double precision, double precision, double precision) returns geometry
LANGUAGE SQL
AS $$
SELECT ST_Affine($1, 1, 0, 0, 0, 1, 0, 0, 0, 1, $2, $3, $4)
$$;
