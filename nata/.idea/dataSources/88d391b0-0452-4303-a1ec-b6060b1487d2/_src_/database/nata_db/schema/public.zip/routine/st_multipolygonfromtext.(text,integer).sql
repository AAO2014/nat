create function st_multipolygonfromtext(text, integer) returns geometry
LANGUAGE SQL
AS $$
SELECT ST_MPolyFromText($1, $2)
$$;
