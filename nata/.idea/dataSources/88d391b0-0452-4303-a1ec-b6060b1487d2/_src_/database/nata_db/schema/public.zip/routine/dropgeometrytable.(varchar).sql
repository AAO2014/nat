create function dropgeometrytable(table_name character varying) returns text
LANGUAGE SQL
AS $$
SELECT DropGeometryTable('','',$1)
$$;
