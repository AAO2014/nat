create function st_approxquantile(rast raster, quantiles double precision[], OUT quantile double precision, OUT value double precision) returns SETOF record
LANGUAGE SQL
AS $$
SELECT _st_quantile($1, 1, TRUE, 0.1, $2)
$$;
