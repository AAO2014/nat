create function st_mlinefromtext(text, integer) returns geometry
LANGUAGE SQL
AS $$
SELECT CASE
	WHEN geometrytype(ST_GeomFromText($1, $2)) = 'MULTILINESTRING'
	THEN ST_GeomFromText($1,$2)
	ELSE NULL END

$$;
