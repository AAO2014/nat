create function st_coveredby(geography, geography) returns boolean
LANGUAGE SQL
AS $$
SELECT $1 && $2 AND _ST_Covers($2, $1)
$$;
