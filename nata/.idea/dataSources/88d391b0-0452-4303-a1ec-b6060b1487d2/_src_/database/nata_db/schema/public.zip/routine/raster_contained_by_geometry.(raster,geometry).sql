create function raster_contained_by_geometry(raster, geometry) returns boolean
LANGUAGE SQL
AS $$
select $1::geometry @ $2
$$;
