create function st_linefromtext(text, integer) returns geometry
LANGUAGE SQL
AS $$
SELECT CASE WHEN geometrytype(ST_GeomFromText($1, $2)) = 'LINESTRING'
	THEN ST_GeomFromText($1,$2)
	ELSE NULL END

$$;
