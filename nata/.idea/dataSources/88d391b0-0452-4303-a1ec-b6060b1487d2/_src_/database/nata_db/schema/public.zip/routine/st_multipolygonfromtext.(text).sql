create function st_multipolygonfromtext(text) returns geometry
LANGUAGE SQL
AS $$
SELECT ST_MPolyFromText($1)
$$;
