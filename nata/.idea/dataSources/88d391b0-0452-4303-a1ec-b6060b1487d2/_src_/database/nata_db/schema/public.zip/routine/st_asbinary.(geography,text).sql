create function st_asbinary(geography, text) returns bytea
LANGUAGE SQL
AS $$
SELECT ST_AsBinary($1::geometry, $2);
$$;
