create function st_intersects(rast raster, nband integer, geom geometry) returns boolean
LANGUAGE SQL
AS $$
SELECT $1::geometry && $3 AND _st_intersects($3, $1, $2)
$$;
