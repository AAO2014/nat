create function st_summarystats(rastertable text, rastercolumn text, exclude_nodata_value boolean) returns summarystats
LANGUAGE SQL
AS $$
SELECT _st_summarystats($1, $2, 1, $3, 1)
$$;
