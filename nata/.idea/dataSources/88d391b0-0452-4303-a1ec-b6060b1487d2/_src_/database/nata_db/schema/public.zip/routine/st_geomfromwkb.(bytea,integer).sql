create function st_geomfromwkb(bytea, integer) returns geometry
LANGUAGE SQL
AS $$
SELECT ST_SetSRID(ST_GeomFromWKB($1), $2)
$$;
