create function lockrow(text, text, text, timestamp without time zone) returns integer
LANGUAGE SQL
AS $$
SELECT LockRow(current_schema(), $1, $2, $3, $4);
$$;
