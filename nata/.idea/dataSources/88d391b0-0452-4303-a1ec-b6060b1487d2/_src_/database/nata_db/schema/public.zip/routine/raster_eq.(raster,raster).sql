create function raster_eq(raster, raster) returns boolean
LANGUAGE SQL
AS $$
SELECT raster_hash($1) = raster_hash($2)
$$;
