create function st_mapalgebraexpr(rast raster, pixeltype text, expression text, nodataval double precision DEFAULT NULL::double precision) returns raster
LANGUAGE SQL
AS $$
SELECT st_mapalgebraexpr($1, 1, $2, $3, $4)
$$;
