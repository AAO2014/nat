create function st_multipointfromtext(text) returns geometry
LANGUAGE SQL
AS $$
SELECT ST_MPointFromText($1)
$$;
