create function postgis_scripts_build_date() returns text
LANGUAGE SQL
AS $$
SELECT '2016-01-22 05:14:15'::text AS version
$$;
