create function st_numpatches(geometry) returns integer
LANGUAGE SQL
AS $$
SELECT CASE WHEN ST_GeometryType($1) = 'ST_PolyhedralSurface'
	THEN ST_NumGeometries($1)
	ELSE NULL END

$$;
