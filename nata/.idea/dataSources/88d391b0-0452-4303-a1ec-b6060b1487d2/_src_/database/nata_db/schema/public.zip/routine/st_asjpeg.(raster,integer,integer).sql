create function st_asjpeg(rast raster, nband integer, quality integer) returns bytea
LANGUAGE SQL
AS $$
SELECT st_asjpeg($1, ARRAY[$2], $3)
$$;
